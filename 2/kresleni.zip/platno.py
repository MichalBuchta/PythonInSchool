import tkinter
canvas = tkinter.Canvas()
canvas.pack()

canvas.create_rectangle(50, 30, 300, 200)
