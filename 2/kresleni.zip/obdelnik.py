import tkinter
canvas = tkinter.Canvas()
canvas.pack()

canvas.create_rectangle(200, 100, 60, 140)
