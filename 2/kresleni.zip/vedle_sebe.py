import tkinter
canvas = tkinter.Canvas()
canvas.pack()

canvas.create_rectangle(80, 80, 160, 160)
canvas.create_rectangle(250, 80, 170, 160)
