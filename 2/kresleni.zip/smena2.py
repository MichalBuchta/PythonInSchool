suma = int(input("zadej sumu: "))
kurz = 25.23

dostanes = suma/kurz

print("dostanete: ",dostanes,"eur za kurz",kurz)