import tkinter
canvas = tkinter.Canvas()
canvas.pack()

canvas.create_rectangle(10, 10, 160, 160)
canvas.create_rectangle(35, 35, 135, 135)
