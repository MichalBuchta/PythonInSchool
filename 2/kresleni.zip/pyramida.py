import tkinter
canvas = tkinter.Canvas()
canvas.pack()

canvas.create_rectangle(50, 80, 125, 65)
canvas.create_rectangle(100, 40, 125, 65)


